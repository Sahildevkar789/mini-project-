
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const Turf = require("../minisahil/models/Turf");
const path = require("path");
const ejsmate = require("ejs-mate");
const session = require('express-session');
const flash = require('connect-flash');
const User = require('./models/User');
const { isLoggedIn } = require('./middleware/auth');
const adminRoutes = require('./routes/admin');
const bookingroutes = require('./routes/bookingroutes');
const userRoutes = require('./routes/userRoutes');
const { body, validationResult } = require('express-validator');
const Booking = require('./models/Booking');
// MongoDB connection
const bodyParser = require('body-parser');
const MONGOURL = 'mongodb://127.0.0.1:27017/mini';  // Your database name
main().then(() => {
    console.log("connected to DB");
}).catch((err) => {
    console.log(err);
});

async function main() {
    await mongoose.connect(MONGOURL);
}

// Set up the views and EJS
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // For parsing JSON data
app.engine("ejs",ejsmate);
app.use(express.static(path.join(__dirname, 'public'))); // For serving static files (CSS, JS, images)


// Session and flash message middleware
app.use(session({
    secret: 'secret-key',  // Change to a secure key in production
    resave: false,
    saveUninitialized: true
}));
app.use(flash());  // Initialize flash messages
// Middleware to make session data available to views
app.use((req, res, next) => {
  res.locals.session = req.session;  // Make session data available in views
  next();
});
// Middleware to make flash messages available to all views
app.use((req, res, next) => {
    res.locals.success = req.flash('success');
    res.locals.error = req.flash('error');
    res.locals.CurrUser =req.user;
    next();
});

// Routes

// Home Route
app.get("/", (req, res) => {
    res.render("listings/home");
});

// All listing turfs

app.get('/book', async (req, res) => {
    try {
        const allTurf = await Turf.find({});
    res.render("listings/index", { allTurf });
    } catch (err) {
        res.status(500).send('Error loading turfs.');
    }
});
// app.get('/listings/:id',isLoggedIn, async (req, res) => {
//     try {
//         const turf = await Turf.findById(req.params.id);
//         const user = await User.findById(req.session.userId);  // Assuming the user is logged in
//         res.render('user/booking', { turf, user });
//     } catch (err) {
//         res.status(500).send('Error loading booking page.');
//     }
// });

// // View specific turf listing
// app.get("/listings/:id",isLoggedIn, async (req, res) => {
//     let { id } = req.params;
//     const turf = await Turf.findById(id);
//     if (!turf) {
//         req.flash("error", "Listing not found");
//         return res.redirect("/book");
//     }
//     res.render("listings/show", { turf });
// });

// Admin Routes
// Booking Routes
const updateBookings = async () => {
    const users = await User.find(); // Fetch all users
    for (const user of users) {
      let updated = false;
      for (const booking of user.bookingHistory) {
        if (!booking.username) {
          // Add the username if it's missing
          booking.username = user.username;
          updated = true;
        }
      }
      if (updated) {
        await user.save(); // Save only if updates were made
        console.log(`Updated bookings for user: ${user.username}`);
      }
    }
  };
  
  updateBookings()
    .then(() => console.log('Finished updating bookingHistory.'))
    .catch((err) => console.error(err));
  
// app.post('/booking/confirm',
//     [
//       body('turfId').notEmpty().withMessage('Turf ID is required'),
//       body('timeSlot').notEmpty().withMessage('Time slot is required'),
//       body('userId').notEmpty().withMessage('User ID is required'),
//     ],
//     async (req, res) => {
//       // Validate request body
//       const errors = validationResult(req);
//       if (!errors.isEmpty()) {
//         return res.status(400).json({ errors: errors.array() });
//       }
  
//       const { turfId, timeSlot, userId } = req.body;
  
//       try {
//           // Find turf by ID
//           const turf = await Turf.findById(turfId);
//           if (!turf) {
//               return res.status(404).send('Turf not found.');
//           }
  
//           // Find the requested time slot
//           const slot = turf.availableSlots.find(s => s.time === timeSlot);
//           if (!slot) {
//               return res.status(400).send('Invalid time slot.');
//           }
  
//           if (slot.isBooked) {
//               return res.status(400).send('This slot is already booked.');
//           }
  
//           // Find user by ID
//           const user = await User.findById(userId);
//           if (!user) {
//               return res.status(404).send('User not found.');
//           }
  
//           // Calculate price and check user's wallet balance
//           const price = turf.pricePerHour;
//           if (user.walletBalance < price) {
//               return res.status(400).send('Insufficient wallet balance.');
//           }
  
//           // Deduct price from user's wallet
//           user.walletBalance -= price;
  
//           // Add booking to user's booking history
//           user.bookingHistory.push({
//             username: user.username, 
//             turfId,
//               timeSlot,
//               price,
//               status: 'paid',
//               bookingDate: new Date(),
//           });
  
//           // Mark the slot as booked
//           slot.isBooked = true;
  
//           // Save updates to user and turf
//           await user.save();
//           await turf.save();
  
          
//           res.status(200).send('Booking confirmed and payment completed from wallet.');
          
//         } catch (err) {
//           console.error(err);
//           res.status(500).send('An error occurred while processing the booking.');
//       }
//   });
app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg'); // Pass success message to the view
    res.locals.error_msg = req.flash('error_msg'); // Pass error message to the view
    next();
  });
  // Route to show available slots for a specific turf based on selected date
//   app.get('/listings/:turfId', async (req, res) => {
//     const turfId = req.params.turfId;
//     const selectedDate = req.query.dateSlot || new Date().toISOString().split('T')[0];  // Default to today
//   console.log(selectedDate);
//     try {
//       const turf = await Turf.findById(turfId);
//       const user = req.session.userId ? await User.findById(req.session.userId) : null;  // Ensure user is fetched from session
  
//       if (!turf) {
//         return res.status(404).send('Turf not found');
//       }
  
//       // If the user is not logged in, redirect to login page (optional)
//       if (!user) {
//         return res.redirect('/login'); // Redirect to login if user is not found
//       }
  
//       // Render the booking page with selected date, turf, and user data
//       res.render('user/booking', { 
//         turf, 
//         user, 
//         selectedDate 
//       });
  
//     } catch (err) {
//       console.error(err);
//       res.status(500).send('Error fetching turf details');
//     }
//   });
  
app.get('/listings/:turfId',isLoggedIn, async (req, res) => {
    const turfId = req.params.turfId;
  
    try {
      const turf = await Turf.findById(turfId); // Find the turf by ID
      const user = req.session.userId ? await User.findById(req.session.userId) : null;  // Get logged-in user if available
  
      if (!turf) {
        return res.status(404).send('Turf not found');
      }
  console.log(turf._id);
      // Render the booking page, passing the user data if logged in
      res.render('user/booking', { turf, user });
  
    } catch (err) {
      console.error(err);
      res.status(500).send('Error fetching turf details');
    }
  });
  



















  app.post('/booking/confirm',
    [
      body('turfId').notEmpty().withMessage('Turf ID is required'),
      body('timeSlot').notEmpty().withMessage('Time slot is required'),
      body('userId').notEmpty().withMessage('User ID is required'),
      body('date').notEmpty().withMessage('Date is required'),  // Ensure date is passed
    ],
    async (req, res) => {
      // Log the request body for debugging
      console.log('Request body:', req.body);
  
      // Validate request body
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
  
      const { turfId, timeSlot, userId, date } = req.body;
  
      try {
        // Find turf by ID
        const turf = await Turf.findById(turfId);
        if (!turf) {
          return res.status(404).send('Turf not found.');
        }
  
        // Find the requested time slot
        const slot = turf.availableSlots.find(
          s => s.dateSlot.toISOString().split('T')[0] === date && s.timeSlot === timeSlot
        );
        if (!slot) {
          return res.status(400).send('Invalid time slot or date.');
        }
  
        if (slot.isBooked) {
          return res.status(400).send('This slot is already booked.');
        }
  
        // Find user by ID
        const user = await User.findById(userId);
        if (!user) {
          return res.status(404).send('User not found.');
        }
  
        // Calculate price and check user's wallet balance
        const price = turf.pricePerHour;
        if (user.walletBalance < price) {
          return res.status(400).send('Insufficient wallet balance.');
        }
  
        // Deduct price from user's wallet
        user.walletBalance -= price;
  
        // Add booking to user's booking history
        const bookingDetails = {
          username: user.username,
          userId: user._id,  // Add userId reference to the booking history
          turfId,
          timeSlot,
          dateSlot: slot.dateSlot,  // Use dateSlot from the available slot
          price,
          status: 'paid',
          bookingDate: new Date(),
        };
  
        user.bookingHistory.push(bookingDetails);
  
        // Mark the slot as booked
        slot.isBooked = true;
  
        // Save updates to user and turf
        await user.save();
        await turf.save();
  
        res.status(200).send('Booking confirmed and payment completed from wallet.');

      } catch (err) {
        console.error(err);
        res.status(500).send('An error occurred while processing the booking.');
      }
    });
  





























app.get('/wallet', async (req, res) => {
    console.log('Session User ID:', req.session.userId);  // Log session data

    try {
        if (!req.session.userId) {
            return res.status(401).send('User not logged in');
        }

        const user = await User.findById(req.session.userId);
        res.render('user/wallet', { walletBalance: user.walletBalance });
    } catch (err) {
        console.error(err);
        res.status(500).send('Error loading wallet.');
    }
});

// Route to add funds to wallet
app.post('/wallet/add', async (req, res) => {
    const { amount } = req.body;

    try {
        const user = await User.findById(req.session.userId);  // Assuming session contains userId
        user.walletBalance += parseFloat(amount);

        user.transactionHistory.push({
            type: 'credit',
            amount: parseFloat(amount),
            description: 'Added funds to wallet',
        });

        await user.save();
        res.redirect('/wallet');
    } catch (err) {
        res.status(500).send('Error adding funds to wallet.');
    }
});
app.get('/booking-history', isLoggedIn, async (req, res) => {
    try {
      const userId = req.session.userId; // Getting the userId from the session
      const user = await User.findById(userId).populate('bookingHistory.turfId'); // Populate turfId with turf details
  
      if (!user) {
        return res.status(404).send('User not found.');
      }
  
      // Render the booking history page and pass the user's booking history
      res.render('user/booking-history', { bookings: user.bookingHistory });
    } catch (err) {
      console.error(err);
      res.status(500).send('Error fetching booking history.');
    }
  });
  
 app.use('/booking', bookingroutes); // Use bookingRoutes for all routes starting with /booking

// User Routes
app.use('/', userRoutes); // Use userRoutes for all routes starting with /user
app.use('/admin', adminRoutes);// Use adminRoutes for all routes starting with /admin

// Start the server
app.listen(2000, () => {
    console.log('Server is listening on port 2000');
});
