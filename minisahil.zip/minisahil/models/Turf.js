const mongoose = require('mongoose');

// Define the Turf Schema
const TurfSchema = new mongoose.Schema({
  title: { type: String, required: true },
  imageUrl: { type: String, required: true },
  pricePerHour: { type: Number, required: true },
  description: { type: String },
  availableSlots: [{  // Available time slots for booking
    dateSlot: { type: Date, required: true },
    timeSlot: { type: String, required: true },
    isBooked: { type: Boolean, default: false }
  }]
});

// Pre-save hook to set default time slots
TurfSchema.pre('save', function(next) {
  if (this.isNew) {  // Only for new documents
    const slots = [];
    const times = [
      '9 AM - 10 AM',
      '10 AM - 11 AM',
      '11 AM - 12 PM',
      '12 PM - 1 PM',
      '1 PM - 2 PM',
      '2 PM - 3 PM',
      '3 PM - 4 PM',
      '4 PM - 5 PM'
    ];

    const today = new Date();
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);  // Increment date by i days

      times.forEach((timeSlot) => {
        slots.push({
          dateSlot: date,
          timeSlot,
          isBooked: false,  // Set all slots as available initially
        });
      });
    }

    this.availableSlots = slots;  // Set the available slots
  }

  next();  // Move to the next operation (saving the document)
});

// Create the Turf model
const Turf = mongoose.model('Turf', TurfSchema);

module.exports = Turf;



// const mongoose = require("mongoose");

// const TurfSchema = new mongoose.Schema({
//   title: { type: String, required: true },
//   imageUrl: { type: String, required: true },
//   pricePerHour: { type: Number, required: true },
//   description: { type: String },
//   availableSlots: [{
//     dateSlot: { type: Date, required: true },
//     timeSlot: { type: String, required: true },
//     isBooked: { type: Boolean, default: false }
//   }]
// });


// // Set default time slots in `pre-save` hook with objects containing both `time` and `isBooked`
// TurfSchema.pre('save', function(next) {
//   if (this.isNew) {
//     this.availableSlots = [
//       { time: "9 AM - 10 AM", isBooked: false },
//       { time: "10 AM - 11 AM", isBooked: false },
//       { time: "11 AM - 12 PM", isBooked: false },
//       { time: "12 PM - 1 PM", isBooked: false },
//       { time: "1 PM - 2 PM", isBooked: false },
//       { time: "2 PM - 3 PM", isBooked: false },
//       { time: "3 PM - 4 PM", isBooked: false },
//       { time: "4 PM - 5 PM", isBooked: false }
//     ];
//   }
//   next();
// });

// const Turf = mongoose.model('Turf', TurfSchema);
// module.exports = Turf;
// // // module.exports = Turf;
// // // const mongoose = require("mongoose");
// // const mongoose = require('mongoose');
// // const TurfSchema = new mongoose.Schema({
// //   title: { type: String, required: true },
// //   imageUrl: { type: String, required: true },
  
// //   pricePerHour: { type: Number, required: true },
// //   description: { type: String },
// //   availableSlots: [
// //     {
// //       dateSlot: { type: Date, required: true },
// //       timeSlot: { type: String, required: true },
// //       isBooked: { type: Boolean, default: false },
// //     },
// //   ],
// // });

// // // Automatically generate slots for the next 30 days
// // TurfSchema.pre('save', function (next) {
// //   if (this.isNew) {
// //     const slots = [];
// //     const times = [
// //       '9 AM - 10 AM',
// //       '10 AM - 11 AM',
// //       '11 AM - 12 PM',
// //       '12 PM - 1 PM',
// //       '1 PM - 2 PM',
// //       '2 PM - 3 PM',
// //       '3 PM - 4 PM',
// //       '4 PM - 5 PM',
// //     ];

// //     const today = new Date();
// //     for (let i = 0; i < 30; i++) {
// //       const date = new Date(today);
// //       date.setDate(today.getDate() + i); // Increment date by i days

// //       times.forEach((time) => {
// //         slots.push({
// //           dateSlot: date, // Use slotDate to track the day
// //           timeSlot,
// //           isBooked: false,
// //         });
// //       });
// //     }

// //     this.availableSlots = slots;
// //   }
// //   next();
// // });
// // const Turf = mongoose.model('Turf', TurfSchema);
// // module.exports = Turf;
